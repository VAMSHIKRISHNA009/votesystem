from django.shortcuts import render, redirect
from django.contrib import messages
from django.db.models import Count
from django.db import IntegrityError
from .forms import VoterForm
from .models import Vote, Party
from .utils import send_otp, blockchain
import logging

logger = logging.getLogger(__name__)

def vote_view(request):
    if request.method == "POST":
        form = VoterForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            phone = form.cleaned_data['phone']
            aadhar = form.cleaned_data['aadhar']
            voter_id = form.cleaned_data['voter_id']

            # Check for duplicate entries (excluding name)
            if Vote.objects.filter(phone=phone).exists() or \
               Vote.objects.filter(aadhar=aadhar).exists() or \
               Vote.objects.filter(voter_id=voter_id).exists():
                messages.error(request, "A vote has already been cast using one of these credentials.")
                logger.warning(f"Duplicate vote attempt: {phone}, {aadhar}, {voter_id}")
                return redirect('alreadyy')

            otp = send_otp(phone)
            if otp:
                request.session.update({
                    'otp': str(otp),
                    'name': name,
                    'phone': phone,
                    'aadhar': aadhar,
                    'voter_id': voter_id
                })
                return redirect('verify_otp')
            else:
                messages.error(request, "Failed to send OTP. Please try again later.")
                logger.error(f"OTP sending failed for phone: {phone}")
    else:
        form = VoterForm()

    return render(request, 'vote.html', {
        'form': form,
        'total_votes': Vote.objects.count()
    })

def verify_otp(request):
    if not request.session.get("otp"):
        messages.error(request, "Session expired. Please start the voting process again.")
        return redirect('vote_view')

    if request.method == "POST":
        entered_otp = request.POST.get("otp")
        session_otp = request.session.get("otp")

        if entered_otp == session_otp:
            request.session['otp_verified'] = True
            return redirect('cast_vote')
        else:
            messages.error(request, "Invalid OTP. Please try again.")

    return render(request, 'verify_otp.html')

def cast_vote(request):
    if not request.session.get('otp_verified'):
        messages.error(request, "Please verify OTP before casting your vote.")
        return redirect('verify_otp')

    if request.method == "POST":
        party_id = request.POST.get("selected_party")
        name = request.session.get("name")
        phone = request.session.get("phone")
        aadhar = request.session.get("aadhar")
        voter_id = request.session.get("voter_id")

        if not all([name, phone, aadhar, voter_id]):
            messages.error(request, "Session expired. Please vote again.")
            return redirect('vote_view')

        if Vote.objects.filter(phone=phone).exists() or \
           Vote.objects.filter(aadhar=aadhar).exists() or \
           Vote.objects.filter(voter_id=voter_id).exists():
            messages.error(request, "Vote already recorded.")
            logger.warning(f"Duplicate vote in cast_vote: {phone}, {aadhar}, {voter_id}")
            return redirect('alreadyy')

        try:
            party = Party.objects.get(id=party_id)
            vote = Vote.objects.create(
                name=name,
                phone=phone,
                aadhar=aadhar,
                voter_id=voter_id,
                party=party
            )
            
            # Add to blockchain
            blockchain.new_vote(name, phone, party.name)
            
            logger.info(f"Vote cast successfully by {phone} for party {party.name}")

            # Clear session
            for key in ['otp', 'otp_verified', 'name', 'phone', 'aadhar', 'voter_id']:
                request.session.pop(key, None)

            return redirect('success')

        except IntegrityError as e:
            messages.error(request, "Your vote could not be saved. It might already exist.")
            logger.error(f"IntegrityError for {phone}: {str(e)}")
            return redirect('alreadyy')

    parties = Party.objects.all()
    return render(request, 'cast_vote.html', {'parties': parties})

def success(request):
    return render(request, 'success.html')

def alreadyy(request):
    return render(request, 'already.html')

def view_blockchain(request):
    blocks = blockchain.get_chain()
    return render(request, 'view_blockchain.html', {'blocks': blocks})

def party_vote_count(request):
    party_votes = Vote.objects.values('party__name').annotate(total_votes=Count('party'))
    return render(request, 'vote_results.html', {'party_votes': party_votes})