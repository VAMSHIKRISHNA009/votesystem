import random
import requests
import hashlib
import time
import json
from datetime import datetime

def send_otp(phone):
    """Send OTP to the given phone number using 2Factor API"""
    otp = str(random.randint(1000, 9999))
    api_key = '300a7523-19ee-11f0-8b17-0200cd936042'  # Replace with your actual 2Factor API key
    url = f"https://2factor.in/API/V1/{api_key}/SMS/{phone}/{otp}"

    try:
        response = requests.get(url)
        print("2Factor response:", response.text)

        if response.status_code == 200:
            data = response.json()
            if data.get("Status") == "Success":
                return otp
            else:
                print("OTP sending failed:", data.get("Details"))
        else:
            print("Error sending OTP:", response.status_code)

    except Exception as e:
        print("Exception:", e)

    return None


class Block:
    def __init__(self, index, name, phone, party, previous_hash):
        """Initialize a new block in the blockchain"""
        self.index = index
        self.timestamp = time.time()
        self.name = name
        self.phone = phone
        self.party = party
        self.previous_hash = previous_hash
        self.hash = self.calculate_hash()

    def calculate_hash(self):
        """Calculate the SHA-256 hash of the block"""
        block_string = json.dumps({
            'index': self.index,
            'timestamp': self.timestamp,
            'name': self.name,
            'phone': self.phone,
            'party': self.party,
            'previous_hash': self.previous_hash
        }, sort_keys=True).encode()
        return hashlib.sha256(block_string).hexdigest()

    def to_dict(self):
        """Convert block data to dictionary for easy serialization"""
        return {
            'index': self.index,
            'timestamp': datetime.fromtimestamp(self.timestamp).strftime('%Y-%m-%d %H:%M:%S'),
            'name': self.name,
            'phone': self.phone,
            'party': self.party,
            'previous_hash': self.previous_hash,
            'hash': self.hash
        }


class Blockchain:
    def __init__(self):
        """Initialize the blockchain with genesis block"""
        self.chain = [self.create_genesis_block()]

    def create_genesis_block(self):
        """Create the first block in the blockchain"""
        return Block(0, 'Genesis', '0000000000', 'Genesis Party', '0')

    def get_latest_block(self):
        """Get the most recent block in the chain"""
        return self.chain[-1]

    def add_block(self, name, phone, party):
        """Add a new block to the blockchain"""
        latest_block = self.get_latest_block()
        new_block = Block(
            index=len(self.chain),
            name=name,
            phone=phone,
            party=party,
            previous_hash=latest_block.hash
        )
        self.chain.append(new_block)
        return new_block

    # Alias for add_block to maintain backward compatibility
    def new_vote(self, name, phone, party):
        """Alternative name for add_block (maintains compatibility with existing code)"""
        return self.add_block(name, phone, party)

    def get_chain(self):
        """Get the entire blockchain as a list of dictionaries"""
        return [block.to_dict() for block in self.chain]

    def is_chain_valid(self):
        """Validate the integrity of the blockchain"""
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i-1]

            # Check if current block hash is correct
            if current_block.hash != current_block.calculate_hash():
                return False

            # Check if previous hash matches
            if current_block.previous_hash != previous_block.hash:
                return False

        return True


# Create a global blockchain instance
blockchain = Blockchain()