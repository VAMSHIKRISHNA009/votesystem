from django import forms


class VoterForm(forms.Form):
    name = forms.CharField(max_length=100, label="Full Name")
    phone = forms.CharField(max_length=15, label="Phone Number")
    
    aadhar = forms.CharField(max_length=12, label="Aadhar Number")
    voter_id = forms.CharField(max_length=20, label="Voter ID")
    