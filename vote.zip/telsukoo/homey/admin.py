from django.contrib import admin
from django.urls import path
from django.shortcuts import render
from .models import Vote, Party, BlockchainLog
from .utils import blockchain

class VoteAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone','party', 'vote_time')

class PartyAdmin(admin.ModelAdmin):
    list_display = ('name', 'symbol', 'get_vote_count')

    def get_vote_count(self, obj):
        return Vote.objects.filter(party=obj).count()
    get_vote_count.short_description = 'Vote Count'

class BlockchainLogAdmin(admin.ModelAdmin):
    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('blockchain/', self.admin_site.admin_view(self.blockchain_view), name='blockchain_view'),
        ]
        return custom_urls + urls

    def blockchain_view(self, request):
        blocks = blockchain.get_chain()
        return render(request, 'blockchain_view.html', {'blocks': blocks})

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

admin.site.register(Vote, VoteAdmin)
admin.site.register(Party, PartyAdmin)
admin.site.register(BlockchainLog, BlockchainLogAdmin)