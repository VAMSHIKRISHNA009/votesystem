from django.db import models

class Party(models.Model):
    name = models.CharField(max_length=100)
    symbol = models.ImageField(upload_to='party_symbols/')

    def _str_(self):
        return self.name


class Vote(models.Model):
    name = models.CharField(max_length=255)
    phone = models.CharField(max_length=15, unique=True)
    aadhar = models.CharField(max_length=12, null=False, default='000000000000')
    voter_id = models.CharField(max_length=15, null=False, default='000000000000000')
    party = models.ForeignKey(Party, on_delete=models.CASCADE)
    vote_time = models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return f'{self.name} voted for {self.party.name}'


class Block(models.Model):
    index = models.IntegerField()
    timestamp = models.DateTimeField()
    data = models.TextField()  # Store vote details in JSON string format
    previous_hash = models.CharField(max_length=64)
    hash = models.CharField(max_length=64)

    def _str_(self):
        return f'Block #{self.index} — Hash: {self.hash[:10]}...'


class BlockchainDisplay(models.Model):
    class Meta:
        verbose_name_plural = "Blockchain Viewer"
        managed = False  # No DB table will be created for this


class BlockchainLog(models.Model):
    class Meta:
        verbose_name_plural = "Blockchain Viewer"

    def _str_(self):
        return "Blockchain View"