"""
URL configuration for telsukoo project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from homey.views import vote_view,verify_otp,success,alreadyy,cast_vote,view_blockchain, party_vote_count

from django.conf.urls.static import static
from django.conf import settings
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.urls import path
from django.conf.urls.static import static



urlpatterns =[
    path('admin/', admin.site.urls),
    
    path("verify_otp/",verify_otp,name="verify_otp"),
    path("success/",success,name="success"),
    path("alreadyy/",alreadyy,name="alreadyy"),
    path("cast_vote/",cast_vote,name="cast_vote"),
    path('vote/',vote_view, name='vote_view'),
    path('verify_otp/', verify_otp, name='verify_otp'),
    path('cast_vote/', cast_vote, name='cast_vote'),
    path('success/', success, name='success'),
    path('already/', alreadyy, name='already'),
    path('view_blockchain/', view_blockchain, name='view_blockchain'),
    path('vote_results/', party_vote_count, name='vote_results'),
]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    
